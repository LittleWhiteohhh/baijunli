<?php
return unserialize('a:2:{i:0;a:4:{s:7:"link_id";s:1:"1";s:9:"link_name";s:24:"简好网络官方网站";s:8:"link_url";s:21:"http://www.phpshe.com";s:10:"link_order";s:1:"1";}i:1;a:4:{s:7:"link_id";s:1:"2";s:9:"link_name";s:18:"PHPSHE商城系统";s:8:"link_url";s:28:"http://www.phpshe.com/phpshe";s:10:"link_order";s:1:"2";}}');
?>