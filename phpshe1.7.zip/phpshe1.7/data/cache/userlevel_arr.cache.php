<?php
return unserialize('a:2:{s:4:"auto";a:1:{i:1;a:6:{s:12:"userlevel_id";s:1:"1";s:14:"userlevel_name";s:12:"普通用户";s:15:"userlevel_value";s:1:"0";s:14:"userlevel_logo";s:0:"";s:13:"userlevel_zhe";s:4:"1.00";s:12:"userlevel_up";s:4:"auto";}}s:4:"hand";a:0:{}}');
?>