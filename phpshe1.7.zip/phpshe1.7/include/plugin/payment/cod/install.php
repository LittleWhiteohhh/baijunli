<?php
$config['name'] = '货到付款';
$config['type'] = 'cod';
$config['desc'] = '送货上门后再收款，支持现金、POS机刷卡、支票支付';
return $config;
?>