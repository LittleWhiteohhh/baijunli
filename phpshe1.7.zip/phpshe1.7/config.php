<?php
$pe['db_host'] = '127.0.0.1'; //数据库主机地址
$pe['db_name'] = 'phpshe_1_7'; //数据库名称
$pe['db_user'] = 'root'; //数据库用户名
$pe['db_pw'] = '123321'; //数据库密码
$pe['db_coding'] = 'utf8'; //数据库编码
$pe['url_model'] = 'pathinfo';//url模式,可选项(pathinfo/pathinfo_safe/php)
define('dbpre','pe_'); //数据库表前缀
?>